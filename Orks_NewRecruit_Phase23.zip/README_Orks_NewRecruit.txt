FORCES OF THE MAELSTROM — ORKS (PERSONAL NEW RECRUIT DATA DRAFT)

Target system: Horus Heresy 2nd Edition: Age of Darkness.
Catalogue: Forces_of_the_Maelstrom_Orks.cat

IMPORTANT STATUS
This is a first-pass importable-format catalogue draft, not a fully interactive finished army list. It indexes the 42 army-list entries and base points costs, and exposes the source unit-entry text and the Orks special-rule/armoury reference in the catalogue so the rules remain readable. Options, model counts, weapon profiles, unit stat profiles, army composition constraints, and validation logic still need structured entry and testing in New Recruit. Do not treat the draft as rules-validated or use it for tournament play without checking the PDF.

RULE VISIBILITY
The full source rule text has also been included in the companion Orks_Source_Rules.txt file. The catalogue includes Orks special rules and reference sections as visible rule entries; each unit includes its source text, including options and unit-specific rules.

INSTALLATION
1. In New Recruit, open Add or Remove Games / data sources and choose the option to import a catalogue file (wording may vary by app version).
2. Import this .cat into the existing Horus Heresy (2022) game system. It relies on that system's game-system ID and profile/cost definitions; it is not a separate .gst game system.
3. If New Recruit rejects the file or does not expose the selections as expected, remove the draft and send me the import error so the XML can be corrected.

SOURCE
Forces of the Maelstrom - Orks v1.7, last updated July 2024; unofficial fan work by Always Strikes First, reproduced in Liber Badab Spiel presentation.


PHASE 2 UPDATE — HQ INTERACTIVITY
The five HQ entries now include model stat profiles and selectable upgrade items with their printed point costs. Because this first interactive pass does not yet encode every mutually-exclusive option group, per-model limit, or detachment-wide restriction, consult the visible source-entry rules before selecting upgrades. Other battlefield roles remain reference-first and will be converted in subsequent passes.


PHASE 3 — ELITES AND TROOPS OPTION PASS
NOBZ MOB: 20 selectable options
WARBIKER NOBZ MOB: 17 selectable options
MEGANOBZ MOB: 7 selectable options
KOMMANDOS MOB: 23 selectable options
FLASH GITZ MOB: 5 selectable options
SKARBOYZ MOB: 16 selectable options
DEFF DREAD MOB: 8 selectable options
GROT TANK MOB: 10 selectable options
BOYZ MOB: 20 selectable options
GRETCHIN MOB: 3 selectable options
BURNA MOB: 11 selectable options
TANKBUSTA MOB: 15 selectable options
KILLA KAN MOB: 7 selectable options
TRUKK: 5 selectable options
Additional models are currently paid upgrade counters, not actual model entries. Per-model and mutually exclusive choices, mandatory additions, transport links and stat profiles remain unfinished. Printed option headings are retained in selection labels. No New Recruit runtime test performed.


PHASE 4 — FAST ATTACK, HEAVY SUPPORT AND LORDS OF WAR
STORMBOYZ MOB: 11 selectable options
WARBIKER MOB: 11 selectable options
DEFFKOPTAS: 5 selectable options
DAKKAJET: 1 selectable options
BURNA-BOMMER: 1 selectable options
BLITZA-BOMMER: 0 selectable options
WAZBOM BLASTAJET: 3 selectable options
WARBUGGY SQUADRON: 7 selectable options
KUSTOM JUNKA SQUADRON: 29 selectable options
MEK GUNZ BATTERY: 9 selectable options
LOOTA MOB: 12 selectable options
BATTLEWAGON SQUADRON: 15 selectable options
LOOTED WAGON SQUADRON: 25 selectable options
BIG TRAKK: 8 selectable options
GROT MEGA-TANK: 10 selectable options
GORKANAUT: 1 selectable options
MORKANAUT: 2 selectable options
MEGA-DREAD: 3 selectable options
SQUIGGOTH: 13 selectable options
STOMPA: 3 selectable options
KILL BLASTA: 3 selectable options
KILL BURSTA: 4 selectable options
GARGANTUAN SQUIGGOTH: 9 selectable options
Printed priced options converted to selectable counters. Combined alternatives, model-specific equipment, mutually exclusive choices, free replacement logic and squadron restrictions are not fully encoded. Source rules retained. XML parsing checked; no New Recruit runtime test.


PHASE 5 — CLANS, KULTS AND RULES
Six clan choices on each Warboss type; three Kult choices on each Big Mek type. Each group permits at most one selection per parent. Army-wide Kult uniqueness, clan alignment, conditional slots, paid clan upgrades and detachment restrictions are manual, not enforced. Added 7 subtype and 38 named special rule definitions and 68 text-matched unit links (review for false matches). Optional zero-point reference entry includes appendix text. Prior catalogue limitations remain, including unverified force/category compatibility and erroneous standalone Kustom Meka-Dread entry from earlier phase. XML parsing checked; no New Recruit runtime test.

PHASE 6 — ARMOURY
71 structured weapon profiles, 43 wargear rules, 406 option links and 23 weapon special rule links. Links are name-matched and require manual review; grouped alternatives may show multiple profiles, default equipment not fully structured, twin-linked variants and kombi weapons need refinement. Complete armoury available on reference entry. Core rule definitions not exhaustively linked. XML parsed, no application test.

PHASE 7 — MODEL COMPOSITION
45 mandatory starting model entries; 22 additional model counters converted; 67 profile/stat reference instances. Base points remain on parent units. Vehicle characteristics are visible rules rather than native vehicle profiles. Alternate model profiles are reference only; replacement logic, per-model equipment, transport changes and crew enforcement are unfinished. XML parsed only; New Recruit runtime and schema not verified.
Warboss: 1 Warboss; rows: Warboss, Arch Overlord
Mega Warboss: 1 Mega Warboss; rows: Mega Warboss, Mega Arch Overlord
Big Mek: 1 Big Mek; rows: Big Mek
Mega Big Mek: 1 Mega Big Mek; rows: Mega Big Mek
Weirdboy: 1 Weirdboy; rows: Weirdboy
Nobz Mob: 3 Nob; rows: Nob, Painboy
Warbiker Nobz Mob: 3 Warbiker Nob; rows: Warbiker Nob, Warbiker Painboy
Meganobz Mob: 3 Meganob; rows: Meganob
Kommandos Mob: 5 Kommando; rows: Kommando, Kommando Nob
Flash Gitz Mob: 2 Flash Git, 1 Kaptin; rows: Flash Git, Kaptin
Skarboyz Mob: 5 Skarboy; rows: Skarboy, Mad Dok
Deff Dread Mob: 1 Deff Dread; rows: Deff Dread
Grot Tank Mob: 3 Grot Tank; rows: Grot Tank
Boyz Mob: 10 Ork Boy; rows: Ork Boy, Boss Nob
Gretchin Mob: 10 Gretchin, 1 Runtherd; rows: Gretchin, Runtherd
Burna Mob: 5 Burna Boy; rows: Burna Boy, Mek
Tankbusta Mob: 5 Tankbusta; rows: Tankbusta, Tankbusta Nob
Killa Kan Mob: 1 Killa Kan; rows: Killa Kan
Trukk: 1 Trukk; rows: Trukk
Stormboyz Mob: 5 Stormboy; rows: Stormboy, Stormboy Nob
Warbiker Mob: 3 Warbiker; rows: Warbiker, Warbiker Nob
Deffkoptas: 1 Deffkopta; rows: Deffkopta
Dakkajet: 1 Dakkajet; rows: Dakkajet
Burna-Bommer: 1 Burna-bommer; rows: Burna-bommer
Blitza-Bommer: 1 Blitza-bommer; rows: Blitza-bommer
Wazbom Blastajet: 1 Wazbom Blastajet; rows: Wazbom Blastajet
Warbuggy Squadron: 1 Warbuggy/Wartrakk; rows: Warbuggy/Wartrakk
Kustom Junka Squadron: 1 Kustom Junka; rows: Kustom Junka
Mek Gunz Battery: 1 Mek Gun, 2 Gretchin Crew; rows: Gretchin Crew, Mek Gun
Loota Mob: 5 Loota; rows: Loota, Mek
Battlewagon Squadron: 1 Battlewagon; rows: Battlewagon
Looted Wagon Squadron: 1 Looted Wagon; rows: Looted Wagon
Big Trakk: 1 Big Trakk; rows: Big Trakk
Grot Mega-Tank: 1 Grot Mega-tank; rows: Grot Mega-tank
Gorkanaut: 1 Gorkanaut; rows: Gorkanaut
Morkanaut: 1 Morkanaut; rows: Morkanaut
Mega-Dread: 1 Mega-dread; rows: Mega-dread
Squiggoth: 1 Squiggoth; rows: Squiggoth
Stompa: 1 Stompa; rows: Stompa
Kill Blasta: 1 Kill Blasta; rows: Kill Blasta
Kill Bursta: 1 Kill Bursta; rows: Kill Bursta
Gargantuan Squiggoth: 1 Gargantuan Squiggoth; rows: Gargantuan Squiggoth
PHASE 8 — HQ EQUIPMENT LOGIC
Rebuilt four HQ equipment lists from printed options; Weirdboy fixed equipment added. Exclusive replacement slots use min/max 1 and default selection IDs. Optional one-of groups use max 1. Ammo runts and grot oilers capped at three. Restored missing HQ options. Kustom Meka-dread removed as standalone unit and added as +30 upgrade with optional +50 KFF; eligibility and HQ role change remain manual. Arch Overlord stat changes, bike stat changes, non-HQ equipment logic, transport logic and native vehicle profiles remain pending. Exact-name equipment links only; some weapons lack matching profiles. XML parsing verified, not runtime or schema validated.

PHASE 9 — PARTIAL INFANTRY LOGIC
Boyz rebuilt with 10–30 model group, 6 points per Boy, 16 per Boss Nob (max one), individual weapon choices and armour. Group default behavior not runtime tested. Heavy weapon quota and whole-mob shoota/armour requirements remain manual. Gretchin starting equipment and Runtherd options improved; additional Runtherd requirements remain manual. Fixed equipment added to Burna, Tankbusta and Stormboy starting/additional model entries. Other infantry and transport logic pending. XML parsing only.

PHASE 10 — ADVANCED INFANTRY (PARTIAL)
Rebuilt Nobz, Warbiker Nobz, Meganobz, Kommandos and Flash Gitz with per-model pricing, composition groups, specialist profiles and equipment slots. Fixed parent surcharges preserve printed base costs (6, 45, 0, 0, 8 respectively). Banner quotas, whole-mob upgrades, Kommando special weapon quotas and transport eligibility remain manual; Kommando Nob alternate paired loadouts pending. Other infantry unchanged. XML parsing only; no New Recruit runtime validation.

PHASE 11 — REMAINING INFANTRY
Rebuilt six mobs with model composition, specialist profiles and equipment slots. Base surcharges preserve printed starting prices. Whole-mob upgrades, special weapon quotas, dedicated transports and KFF limits remain manual. XML parsed; runtime not tested.

PHASE 12 — VEHICLES AND WALKERS (PART 1)
Rebuilt Deff Dread, Killa Kan, Grot Tank, Trukk, Warbuggy and Battlewagon with per-model pricing and equipment groups. Native vehicle profiles, remaining vehicles, dynamic stat changes, Kommanda limit and transport eligibility remain unfinished. XML parsed; runtime not tested.

PHASE 13 — VEHICLES PART II
Seven entries rebuilt with per-vehicle selections and weapon slots. Dynamic stats and transport changes remain manual. Junka first-model surcharge 5 pts retained; Grot Mega-tank optional equipment interpreted as applying to itself. Runtime not tested.

PHASE 14 — AIRCRAFT AND LORDS OF WAR
Ten entries rebuilt with equipment selections. Kill Bursta options interpreted as applying to Kill Bursta despite source copy error. Deffkopta first-model surcharge 3 points. Transport changes remain manual; native vehicle profiles and runtime testing pending. XML parsed.

PHASE 15 — STRUCTURED VEHICLE PROFILES
17 profiles added using two catalogue-local profile types (official system characteristic IDs could not be verified). Original rule descriptions retained. Equipment-dependent changes remain manual. XML parsed; runtime and schema not tested.
Grot Tank: {'BS': '3', 'Front': '10', 'Side': '10', 'Rear': '10', 'HP': '2', 'Transport Capacity': '-', 'Unit Type': 'Vehicle', 'Move': '2D6', 'Access Points': '—'}
Trukk: {'BS': '2', 'Front': '10', 'Side': '10', 'Rear': '10', 'HP': '3', 'Transport Capacity': '12', 'Unit Type': 'Vehicle (Fast, Open-topped, Transport)', 'Move': '16', 'Access Points': 'Entire vehicle'}
Dakkajet: {'BS': '2', 'Front': '10', 'Side': '10', 'Rear': '10', 'HP': '3', 'Transport Capacity': '-', 'Unit Type': 'Vehicle (Flyer)', 'Move': '20', 'Access Points': '—'}
Burna-bommer: {'BS': '2', 'Front': '10', 'Side': '10', 'Rear': '10', 'HP': '3', 'Transport Capacity': '-', 'Unit Type': 'Vehicle (Flyer)', 'Move': '18', 'Access Points': '—'}
Blitza-bommer: {'BS': '2', 'Front': '10', 'Side': '10', 'Rear': '10', 'HP': '3', 'Transport Capacity': '-', 'Unit Type': 'Vehicle (Flyer)', 'Move': '18', 'Access Points': '—'}
Wazbom Blastajet: {'BS': '3', 'Front': '10', 'Side': '10', 'Rear': '10', 'HP': '3', 'Transport Capacity': '-', 'Unit Type': 'Vehicle (Flyer)', 'Move': '18', 'Access Points': '—'}
Warbuggy/Wartrakk: {'BS': '2', 'Front': '10', 'Side': '10', 'Rear': '10', 'HP': '2', 'Transport Capacity': '-', 'Unit Type': 'Vehicle (Fast)', 'Move': '16', 'Access Points': '—'}
Kustom Junka: {'BS': '2', 'Front': '11', 'Side': '10', 'Rear': '10', 'HP': '3', 'Transport Capacity': '-', 'Unit Type': 'Vehicle (Fast, Open-topped)', 'Move': '16', 'Access Points': '—'}
Battlewagon: {'BS': '2', 'Front': '14', 'Side': '12', 'Rear': '10', 'HP': '4', 'Transport Capacity': '20', 'Unit Type': 'Vehicle (Open-topped, Transport)', 'Move': '12', 'Access Points': 'Entire vehicle; with ard case: both sides and rear'}
Looted Wagon: {'BS': '2', 'Front': '11', 'Side': '11', 'Rear': '10', 'HP': '3', 'Transport Capacity': '12', 'Unit Type': 'Vehicle (Open-topped, Transport)', 'Move': '14', 'Access Points': 'Entire vehicle; with ard case: rear'}
Big Trakk: {'BS': '2', 'Front': '12', 'Side': '11', 'Rear': '10', 'HP': '3', 'Transport Capacity': '12', 'Unit Type': 'Vehicle (Open-topped, Transport)', 'Move': '12', 'Access Points': 'Entire vehicle; with ard case: rear'}
Grot Mega-tank: {'BS': '3', 'Front': '12', 'Side': '11', 'Rear': '10', 'HP': '3', 'Transport Capacity': '-', 'Unit Type': 'Vehicle', 'Move': '2D6', 'Access Points': '—'}
Gorkanaut: {'WS': '4', 'BS': '2', 'S': '8', 'Front': '13', 'Side': '13', 'Rear': '12', 'I': '2', 'A': '4', 'HP': '5', 'Transport Capacity': '6', 'Unit Type': 'Vehicle (Knight, Transport)', 'Move': '6', 'Access Points': 'Front'}
Morkanaut: {'WS': '4', 'BS': '2', 'S': '8', 'Front': '13', 'Side': '13', 'Rear': '12', 'I': '2', 'A': '4', 'HP': '5', 'Transport Capacity': '6', 'Unit Type': 'Vehicle (Knight, Transport)', 'Move': '6', 'Access Points': 'Front'}
Stompa: {'WS': '5', 'BS': '2', 'S': '10', 'Front': '13', 'Side': '13', 'Rear': '12', 'I': '1', 'A': '4', 'HP': '14', 'Transport Capacity': '20', 'Unit Type': 'Vehicle (Titan, Transport)', 'Move': '12', 'Access Points': 'Rear'}
Kill Blasta: {'BS': '2', 'Front': '14', 'Side': '13', 'Rear': '10', 'HP': '7', 'Transport Capacity': '-', 'Unit Type': 'Vehicle (Super-heavy)', 'Move': '14', 'Access Points': '—'}
Kill Bursta: {'BS': '2', 'Front': '14', 'Side': '13', 'Rear': '10', 'HP': '7', 'Transport Capacity': '-', 'Unit Type': 'Vehicle (Super-heavy)', 'Move': '14', 'Access Points': '—'}
PHASE 16 — CONDITIONAL PROFILE MODIFIERS
Nob: Save set 4+ if ‘Eavy armour
Painboy: Save set 4+ if ‘Eavy armour
Skarboy: Save set 4+ if ‘Eavy armour
Mad Dok: Save set 4+ if ‘Eavy armour
Deff Dread: A increment 1 if Dread klaw or Dread saw
Deff Dread: A increment 1 if Dread klaw or Dread saw
Ork Boy: Save set 4+ if ‘Eavy armour
Boss Nob: Save set 4+ if ‘Eavy armour
Burna Boy: Save set 4+ if ‘Eavy armour
Mek: Save set 4+ if ‘Eavy armour
Tankbusta: Save set 4+ if ‘Eavy armour
Tankbusta Nob: Save set 4+ if ‘Eavy armour
Stormboy: Save set 4+ if ‘Eavy armour
Stormboy Nob: Save set 4+ if ‘Eavy armour
Kustom Junka: Unit Type set Vehicle (Fast) if ‘Ard case
Loota: Save set 4+ if ‘Eavy armour
Mek: Save set 4+ if ‘Eavy armour
Battlewagon: Transport Capacity set 12 if Turret Mounted killkannon
Battlewagon: Unit Type set Vehicle (Transport) if ‘Ard case
Battlewagon: Access Points set Both sides and rear if ‘Ard case
Looted Wagon: HP set 4 if HP 4 / Move 12
Looted Wagon: Move set 12 if HP 4 / Move 12
Looted Wagon: HP set 5 if HP 5 / Move 10
Looted Wagon: Move set 10 if HP 5 / Move 10
Looted Wagon: Unit Type set Vehicle (Transport) if ‘Ard case
Looted Wagon: Access Points set Rear if ‘Ard case
Looted Wagon: Front increment 2 if ‘Eavy plates
Looted Wagon: Side increment 1 if ‘Eavy plates
Looted Wagon: Transport Capacity set - if Skorcha or Deffgun or Killkannon or Kustom mega-blasta or Kannon or Lobba or Zzap gun
Looted Wagon: Unit Type set Vehicle (Open-topped) if Skorcha or Deffgun or Killkannon or Kustom mega-blasta or Kannon or Lobba or Zzap gun
Looted Wagon: Unit Type set Vehicle if Skorcha or Deffgun or Killkannon or Kustom mega-blasta or Kannon or Lobba or Zzap gun AND Ard Case
Big Trakk: Unit Type set Vehicle (Transport) if ‘Ard case
Big Trakk: Access Points set Rear if ‘Ard case
Big Trakk: Transport Capacity set - if Flakka gunz or Supa kannon
Big Trakk: Unit Type set Vehicle (Open-topped) if Flakka gunz or Supa kannon
Big Trakk: Unit Type set Vehicle if Flakka gunz or Supa kannon AND Ard Case
Mega-dread: A set 3 if Killkannon or Killkannon
Modifiers use parent-scoped selection conditions; runtime and schema untested. Grot gunner, majority Light subtype, Feel No Pain and other complex effects remain manual.

PHASE 17 — DEDICATED TRANSPORTS
Eight units now have optional nested transport groups, with 12 choices (see list below). Each transport is a cloned configurable entry with fresh internal IDs, no category link and a one-vehicle squadron cap. Tellyporta Assault hides these groups via provisional force-scoped conditions. Capacity, clan alternatives, compulsory slots, Warlord and army-wide restrictions remain manual. No New Recruit runtime test.
Nobz Mob: Trukk, Battlewagon Squadron
Meganobz Mob: Trukk, Battlewagon Squadron
Flash Gitz Mob: Trukk, Battlewagon Squadron
Skarboyz Mob: Trukk
Boyz Mob: Trukk
Burna Mob: Trukk
Tankbusta Mob: Trukk
Loota Mob: Trukk, Looted Wagon Squadron
PHASE 18 — GREAT CLAN ALIGNMENT
240 optional alignment selections and 20 conditional transport alternatives. Visibility uses provisional force and parent scopes. Clan effects and combined detachment limits are visible reminders, not automatic validation. Warboss-specific upgrades, Warlord, automatic movement and other profile changes remain pending. No runtime test.

PHASE 19 — KULTS
Four conditional alternate Troops entries, three paid Deep Strike options, Blood Axes training and Goffs rokkit pack, conditional Gretchin hiding and provisional roster-wide Kult exclusion. Alternate entries are copies; combined limits and compulsory status remain manual. Kustom Meka-Dread HQ, Cyboar, Bad Moons and Deathskulls weapons, Warlord, full Kult restrictions and runtime testing remain pending. Reminder options are optional and zero points.

PHASE 20 — WARLORDS
Six provisional Warlord selectors with three traits each; conditional Kustom Meka-Dread HQ copy with mandatory upgrade; Bad Moons Snazzgun replacement; cross-entry Arch Overlord and banner visibility restrictions. Warlord precedence, Deathskulls weapon pricing, Cyboar replacements, compulsory slots and combined clan limits remain manual. Conditions and profile links not runtime tested.

PHASE 21 — Four conditional Evil Sunz transport choices; provisional Warlord precedence visibility; five Cyboar reference rules. Retinue eligibility, actual Cyboar replacement, mandatory Warlord selection, Deathskulls prices, combined clan limits and compulsory slots remain manual. No runtime test.

PHASE 22 — STATIC VALIDATION
XML parsing: PASS
ID-bearing elements: 8098
Duplicate IDs: 0
targetId: 1849 references; 0 unresolved locally
childId: 1083 references; 0 unresolved locally
defaultSelectionEntryId: 154 references; 0 unresolved locally
publicationId: 0 references; 0 unresolved locally
External profile and cost type IDs not verified against live GST.
Four source-checked special weapon allowance reminders added; not automatic constraints.
No New Recruit runtime or schema validation performed.
Remaining: universal rule integration, compulsory slots, clan combined limits, Cyboar replacement, Deathskulls options, mandatory Warlord and runtime tests.

PHASE 23
Cyboar mount groups: 8
XML parsing: PASS
Duplicate IDs: 0
targetId: 1849 references, 0 unresolved locally
childId: 1091 references, 0 unresolved locally
defaultSelectionEntryId: 160 references, 0 unresolved locally
Cyboar visibility uses unit-scoped conditions; runtime untested. Profile changes remain descriptive. External GST retrieval failed; universal rules, categories, compulsory slots and other restrictions remain unverified.
